package com.tokopedia.testproject.problems.algorithm.maxrectangle;


public class Solution {
    public static int maxRect(int[][] matrix) {
        // TODO, return the largest area containing 1's, given the 2D array of 0s and 1s
        // below is stub
        return 0;
    }
}
